﻿namespace test6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label1 = new Label();
            SidBOX = new TextBox();
            groupBox2 = new GroupBox();
            SEXWOMEN = new RadioButton();
            SEXMAN = new RadioButton();
            SEX = new RadioButton();
            groupBox3 = new GroupBox();
            SelectAge = new RadioButton();
            Ages = new ComboBox();
            RandomAge = new RadioButton();
            groupBox4 = new GroupBox();
            Sxing = new ComboBox();
            selectXING = new RadioButton();
            randomXIN = new RadioButton();
            groupBox5 = new GroupBox();
            NameL2 = new RadioButton();
            NameL1 = new RadioButton();
            NameL = new RadioButton();
            groupBox6 = new GroupBox();
            YXS = new ComboBox();
            SelectYX = new RadioButton();
            randomYX = new RadioButton();
            groupBox7 = new GroupBox();
            SelectZZMM = new RadioButton();
            RandomZZMM = new RadioButton();
            groupBox8 = new GroupBox();
            numericUpDown1 = new NumericUpDown();
            dataGridView1 = new DataGridView();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            progressBar1 = new ProgressBar();
            ZZMM = new ComboBox();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox7.SuspendLayout();
            groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(SidBOX);
            groupBox1.Location = new Point(38, 24);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(250, 125);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "学号";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 53);
            label1.Name = "label1";
            label1.Size = new Size(69, 20);
            label1.TabIndex = 1;
            label1.Text = "默认学号";
            // 
            // SidBOX
            // 
            SidBOX.Location = new Point(105, 51);
            SidBOX.Name = "SidBOX";
            SidBOX.Size = new Size(125, 27);
            SidBOX.TabIndex = 0;
            SidBOX.Text = "20200001";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(SEXWOMEN);
            groupBox2.Controls.Add(SEXMAN);
            groupBox2.Controls.Add(SEX);
            groupBox2.Location = new Point(403, 24);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(250, 91);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "性别";
            // 
            // SEXWOMEN
            // 
            SEXWOMEN.AutoSize = true;
            SEXWOMEN.Location = new Point(166, 35);
            SEXWOMEN.Name = "SEXWOMEN";
            SEXWOMEN.Size = new Size(45, 24);
            SEXWOMEN.TabIndex = 15;
            SEXWOMEN.TabStop = true;
            SEXWOMEN.Text = "女";
            SEXWOMEN.UseVisualStyleBackColor = true;
            // 
            // SEXMAN
            // 
            SEXMAN.AutoSize = true;
            SEXMAN.Location = new Point(85, 35);
            SEXMAN.Name = "SEXMAN";
            SEXMAN.Size = new Size(45, 24);
            SEXMAN.TabIndex = 14;
            SEXMAN.TabStop = true;
            SEXMAN.Text = "男";
            SEXMAN.UseVisualStyleBackColor = true;
            // 
            // SEX
            // 
            SEX.AutoSize = true;
            SEX.Location = new Point(6, 35);
            SEX.Name = "SEX";
            SEX.Size = new Size(60, 24);
            SEX.TabIndex = 13;
            SEX.TabStop = true;
            SEX.Text = "随机";
            SEX.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(SelectAge);
            groupBox3.Controls.Add(Ages);
            groupBox3.Controls.Add(RandomAge);
            groupBox3.Location = new Point(403, 150);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(250, 88);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "年龄";
            // 
            // SelectAge
            // 
            SelectAge.AutoSize = true;
            SelectAge.Location = new Point(85, 40);
            SelectAge.Name = "SelectAge";
            SelectAge.Size = new Size(60, 24);
            SelectAge.TabIndex = 16;
            SelectAge.TabStop = true;
            SelectAge.Text = "选择";
            SelectAge.UseVisualStyleBackColor = true;
            // 
            // Ages
            // 
            Ages.FormattingEnabled = true;
            Ages.Location = new Point(151, 39);
            Ages.Name = "Ages";
            Ages.Size = new Size(84, 28);
            Ages.TabIndex = 15;
            // 
            // RandomAge
            // 
            RandomAge.AutoSize = true;
            RandomAge.Location = new Point(15, 40);
            RandomAge.Name = "RandomAge";
            RandomAge.Size = new Size(60, 24);
            RandomAge.TabIndex = 14;
            RandomAge.TabStop = true;
            RandomAge.Text = "随机";
            RandomAge.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(Sxing);
            groupBox4.Controls.Add(selectXING);
            groupBox4.Controls.Add(randomXIN);
            groupBox4.Location = new Point(38, 168);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(250, 88);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "姓名 是否指定姓";
            // 
            // Sxing
            // 
            Sxing.FormattingEnabled = true;
            Sxing.Location = new Point(168, 36);
            Sxing.Name = "Sxing";
            Sxing.Size = new Size(53, 28);
            Sxing.TabIndex = 14;
            // 
            // selectXING
            // 
            selectXING.AutoSize = true;
            selectXING.Location = new Point(87, 37);
            selectXING.Name = "selectXING";
            selectXING.Size = new Size(75, 24);
            selectXING.TabIndex = 13;
            selectXING.TabStop = true;
            selectXING.Text = "指定姓";
            selectXING.UseVisualStyleBackColor = true;
            // 
            // randomXIN
            // 
            randomXIN.AutoSize = true;
            randomXIN.Location = new Point(6, 37);
            randomXIN.Name = "randomXIN";
            randomXIN.Size = new Size(75, 24);
            randomXIN.TabIndex = 0;
            randomXIN.TabStop = true;
            randomXIN.Text = "随机姓";
            randomXIN.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(NameL2);
            groupBox5.Controls.Add(NameL1);
            groupBox5.Controls.Add(NameL);
            groupBox5.Location = new Point(38, 297);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(250, 88);
            groupBox5.TabIndex = 4;
            groupBox5.TabStop = false;
            groupBox5.Text = "名长度";
            // 
            // NameL2
            // 
            NameL2.AutoSize = true;
            NameL2.Location = new Point(152, 26);
            NameL2.Name = "NameL2";
            NameL2.Size = new Size(39, 24);
            NameL2.TabIndex = 13;
            NameL2.TabStop = true;
            NameL2.Text = "2";
            NameL2.UseVisualStyleBackColor = true;
            // 
            // NameL1
            // 
            NameL1.AutoSize = true;
            NameL1.Location = new Point(87, 26);
            NameL1.Name = "NameL1";
            NameL1.Size = new Size(39, 24);
            NameL1.TabIndex = 13;
            NameL1.TabStop = true;
            NameL1.Text = "1";
            NameL1.UseVisualStyleBackColor = true;
            // 
            // NameL
            // 
            NameL.AutoSize = true;
            NameL.Location = new Point(6, 26);
            NameL.Name = "NameL";
            NameL.Size = new Size(60, 24);
            NameL.TabIndex = 0;
            NameL.TabStop = true;
            NameL.Text = "随机";
            NameL.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(YXS);
            groupBox6.Controls.Add(SelectYX);
            groupBox6.Controls.Add(randomYX);
            groupBox6.Location = new Point(403, 272);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(325, 88);
            groupBox6.TabIndex = 5;
            groupBox6.TabStop = false;
            groupBox6.Text = "所在院系";
            // 
            // YXS
            // 
            YXS.FormattingEnabled = true;
            YXS.Location = new Point(151, 37);
            YXS.Name = "YXS";
            YXS.Size = new Size(168, 28);
            YXS.TabIndex = 16;
            // 
            // SelectYX
            // 
            SelectYX.AutoSize = true;
            SelectYX.Location = new Point(94, 38);
            SelectYX.Name = "SelectYX";
            SelectYX.Size = new Size(60, 24);
            SelectYX.TabIndex = 17;
            SelectYX.TabStop = true;
            SelectYX.Text = "选择";
            SelectYX.UseVisualStyleBackColor = true;
            // 
            // randomYX
            // 
            randomYX.AutoSize = true;
            randomYX.Location = new Point(15, 38);
            randomYX.Name = "randomYX";
            randomYX.Size = new Size(60, 24);
            randomYX.TabIndex = 15;
            randomYX.TabStop = true;
            randomYX.Text = "随机";
            randomYX.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(SelectZZMM);
            groupBox7.Controls.Add(RandomZZMM);
            groupBox7.Location = new Point(403, 402);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(289, 88);
            groupBox7.TabIndex = 6;
            groupBox7.TabStop = false;
            groupBox7.Text = "政治面貌";
            // 
            // SelectZZMM
            // 
            SelectZZMM.AutoSize = true;
            SelectZZMM.Location = new Point(85, 38);
            SelectZZMM.Name = "SelectZZMM";
            SelectZZMM.Size = new Size(60, 24);
            SelectZZMM.TabIndex = 18;
            SelectZZMM.TabStop = true;
            SelectZZMM.Text = "选择";
            SelectZZMM.UseVisualStyleBackColor = true;
            // 
            // RandomZZMM
            // 
            RandomZZMM.AutoSize = true;
            RandomZZMM.Location = new Point(6, 38);
            RandomZZMM.Name = "RandomZZMM";
            RandomZZMM.Size = new Size(60, 24);
            RandomZZMM.TabIndex = 16;
            RandomZZMM.TabStop = true;
            RandomZZMM.Text = "随机";
            RandomZZMM.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            groupBox8.Controls.Add(numericUpDown1);
            groupBox8.Location = new Point(38, 417);
            groupBox8.Name = "groupBox8";
            groupBox8.Size = new Size(250, 73);
            groupBox8.TabIndex = 7;
            groupBox8.TabStop = false;
            groupBox8.Text = "个数";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(53, 26);
            numericUpDown1.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numericUpDown1.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(150, 27);
            numericUpDown1.TabIndex = 0;
            numericUpDown1.Value = new decimal(new int[] { 200, 0, 0, 0 });
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(734, 24);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(851, 463);
            dataGridView1.TabIndex = 8;
            // 
            // button1
            // 
            button1.Location = new Point(418, 519);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 9;
            button1.Text = "生成";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(711, 519);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 10;
            button2.Text = "加载";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(1005, 519);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 11;
            button3.Text = "清除";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(38, 519);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(250, 29);
            progressBar1.TabIndex = 12;
            // 
            // ZZMM
            // 
            ZZMM.FormattingEnabled = true;
            ZZMM.Location = new Point(554, 436);
            ZZMM.Name = "ZZMM";
            ZZMM.Size = new Size(132, 28);
            ZZMM.TabIndex = 18;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(1186, 519);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(125, 125);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1621, 665);
            Controls.Add(pictureBox1);
            Controls.Add(ZZMM);
            Controls.Add(progressBar1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(groupBox8);
            Controls.Add(groupBox7);
            Controls.Add(groupBox6);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "批量学生记录生成器";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private GroupBox groupBox5;
        private GroupBox groupBox6;
        private GroupBox groupBox7;
        private GroupBox groupBox8;
        private Label label1;
        private TextBox SidBOX;
        private RadioButton selectXING;
        private RadioButton randomXIN;
        private DataGridView dataGridView1;
        private Button button1;
        private Button button2;
        private Button button3;
        private ProgressBar progressBar1;
        private ComboBox Sxing;
        private RadioButton NameL2;
        private RadioButton NameL1;
        private RadioButton NameL;
        private RadioButton SEXWOMEN;
        private RadioButton SEXMAN;
        private RadioButton SEX;
        private RadioButton SelectAge;
        private ComboBox Ages;
        private RadioButton RandomAge;
        private ComboBox YXS;
        private RadioButton SelectYX;
        private RadioButton randomYX;
        private RadioButton SelectZZMM;
        private RadioButton RandomZZMM;
        private ComboBox ZZMM;
        private NumericUpDown numericUpDown1;
        public PictureBox pictureBox1;
    }
}